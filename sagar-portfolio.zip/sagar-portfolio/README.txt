SAGAR DAYAL BHAGAT — PERSONAL PORTFOLIO WEBSITE

Files
- index.html: complete responsive portfolio website. No build step or external dependencies required.

Preview locally
1. Open index.html in a web browser.

Publish for a public LinkedIn website link
- GitHub Pages: create a GitHub repository, upload index.html, then enable Pages in repository Settings.
- Netlify: upload the folder to Netlify's manual deploy page.
- Other static hosting services also work.

Before publishing
- Confirm that you want your phone number and email address from your resume visible publicly. This version uses your email address for contact and does not display your phone number.
- Verify any profile details and certification names before sharing.
